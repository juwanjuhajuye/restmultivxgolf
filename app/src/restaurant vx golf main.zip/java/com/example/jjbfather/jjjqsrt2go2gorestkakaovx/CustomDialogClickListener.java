package com.example.jjbfather.jjjqsrt2go2gorestkakaovx;

public interface CustomDialogClickListener {
    void onPositiveClick();
    void onMiddClick();
    void onNegativeClick();
}